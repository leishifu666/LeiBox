# LeiBox · ei 连字矢量成稿与标准制图

用户最终选择原来的圆润 ei 连字，而不是后续的方箱变体。左侧图形直接引用项目 `public/leibox-mark.svg` 的正式路径，字标依据本目录 `selected-reference.png` 做几何规整。

## 成品

- [完整黑色组合 SVG](logo.svg) · [透明 PNG](logo.png)
- [完整反白 SVG](logo-white.svg) · [反白透明 PNG](logo-white.png)
- [字标独立 SVG](wordmark.svg)
- [ei 连字细节 SVG](ei-detail.svg) · [细节预览](ei-detail.png)
- [组合预览](logo-preview.png) · [深底反白预览](inverse-preview.png)

Logo 中所有文字均已重建为闭合轮廓，不使用字体或嵌入位图。各字形、ei 的共笔、竖干和圆点有独立路径 ID，可在矢量软件中编辑。左侧图形保持既有 SVG 的原始 `d`，仅做等比缩放与定位；没有重画或替换其负形 L。

## 标准制图

- [组合比例定位制图 SVG](construction.svg) · [PNG](construction.png)
- [字标几何细节 SVG](lettering-construction.svg) · [PNG](lettering-construction.png)
- [小尺寸与反白检查](size-check.png)

第一张为 B 式比例定位表达：图形、图文间距、字标宽度、字高线、基线、原图标的实际构造圆与 ei 连字的共享笔画。第二张补充字标中的真实圆、椭圆、端圆及 B 字腔的三次 Bézier 参数。排线仅用于制图，成品保持纯色透明。

本次定义 x = 主笔画 16u。组合图形高为 13x，图文净距为 2.75x，字标高为 6.25x，字标宽为 23x，组合宽约为 37.744x。ei 连笔及 i 竖干使用 0.875x 作为光学校正；不是所有笔画被强制做成同宽。标注显示到三位小数，原始精度保留在参数文件中。

## 保留与调整

- 保留 LeiBox 拼写、圆润 L、e-i 斜向连笔、独立圆点、e 下方开口、B 双字腔及 o 内白。
- 规整位图边缘与圆角，校正连笔粗细、i 的位置和 x 的字宽。e 的圆弧端部与连笔下沿按相切约束定位，避免并集边界出现多余凸起。
- B 使用独立三次曲线保留字腔比例；o 使用椭圆，未将它们虚构为正圆。
- ei 中字母笔画的交汇处保留字形需要的转角；解析相切检查针对实际圆弧、端圆和直线的平滑接缝，不声称整个字标处处光滑。

## 已运行的验证

`validation.json` 记录原 SVG 路径及 SHA-256 一致、成品不含字体/位图、透明与反白 alpha 一致、实际导出的圆弧接缝，以及 16 / 24 / 25 / 32 / 48px 栅格检查。32px 和 48px 下，三个 alpha 阈值都保持预期的 7 个实体与 5 个孔洞；24/25px 对阈值较敏感，16px 已有粘连，所以推荐组合标志最小高度 32px。

[最终字标原图对照](review-accepted/comparison.png)、[差异叠加](review-accepted/difference.png)和 [数值记录](review-accepted/review.json)使用整体等比缩放和中心配准，没有局部拉伸。原图字标仅 92×25 像素；重建后的字标保留原来的 6 个实体与 4 个孔洞。面积交并比与轮廓距离属于像素对照，不等于品牌识别准确率。

最终字标像素交并比为 84.86%；平均轮廓偏差约 0.28 个原图像素，P95 约 0.91 像素、最大约 1.72 像素。原图阈值为 128，边界没有降采样。成品和两张制图从参数重新生成后，5 个关键 SVG 的 SHA-256 完全一致，记录在 `rebuild-check.json`。

这是对用户选定图的几何规整；精确半径、模数和字距为本次拟合及定义，没有推断原字体名称。已查看实际成品、反白、原图叠加、ei 局部和两张制图。未做外部人员识别测试或印刷打样。

## 参数复建

在项目根目录运行：

```powershell
node design/brand/leibox-ei-20261023/build.mjs
python design/brand/leibox-ei-20261023/validate.py
```

`parameters.json` 是编辑入口，`geometry.json` 包含计算后的精确坐标、轮廓与构造依据。制作前结构基线在 `source-baseline.json`；中间稿与检查记录独立保存。本次交付保存于设计目录，未替换线上网站的 Logo。
